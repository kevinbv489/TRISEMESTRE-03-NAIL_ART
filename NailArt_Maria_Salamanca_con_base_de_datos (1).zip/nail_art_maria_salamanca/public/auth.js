/* Cuentas: registro, inicio de sesión y roles. La validación real (contraseñas, código de
   administrador, permisos) ocurre en el servidor; aquí solo se muestra la interfaz según el rol. */
(function () {
  let me = null;                                   // usuario con sesión iniciada (o null)
  window.currentUser = () => me;
  window.isAdmin = () => !!me && me.role === "administrador";

  /* ---------- Navegación protegida (la protección real está en el servidor) ---------- */
  const NEED_LOGIN = ["agendar", "miscitas"], NEED_ADMIN = ["clientes", "citas"], GUEST_ONLY = ["login", "registro"];
  let pendingView = null;
  const baseGo = window.go;
  window.go = function (view) {
    if (NEED_ADMIN.includes(view) && !isAdmin()) {
      if (!me) { pendingView = view; toast("Inicia sesión como administrador para entrar."); return baseGo("login"); }
      toast("Esta sección es solo para administradores."); return baseGo("inicio");
    }
    if (NEED_LOGIN.includes(view) && !me) { pendingView = view; toast("Inicia sesión o crea tu cuenta para continuar."); return baseGo("login"); }
    if (GUEST_ONLY.includes(view) && me) return baseGo("inicio");
    baseGo(view);
    if (view === "agendar") { prefillBooking(); refreshAvailability(); }
  };
  window.prefillBooking = function () {
    const f = document.getElementById("bookingForm"); if (!me || !f) return;
    if (!f.elements.name.value) f.elements.name.value = me.name;
    if (!f.elements.phone.value) f.elements.phone.value = me.phone;
    if (!f.elements.email.value) f.elements.email.value = me.email;
  };

  /* ---------- Interfaz según el rol ---------- */
  window.refreshAuthUI = function () {
    const role = me ? me.role : null;
    document.querySelectorAll("[data-show]").forEach(el => {
      const w = el.dataset.show;
      el.hidden = !((w === "guest" && !me) || (w === "user" && me) || (w === "cliente" && role === "cliente") || (w === "admin" && role === "administrador"));
    });
    if (me) {
      document.getElementById("userAvatar").textContent = me.name.trim().charAt(0).toUpperCase();
      document.getElementById("userName").textContent = me.name.split(" ")[0];
      document.getElementById("userRole").textContent = role === "administrador" ? "Administrador" : "Cliente";
    }
  };
  window.onSessionExpired = function () {
    if (!me) return;
    me = null; refreshAuthUI(); toast("Tu sesión expiró. Inicia sesión de nuevo."); baseGo("login");
  };
  function afterLogin(u) {
    me = u; refreshAuthUI();
    const target = pendingView && !(NEED_ADMIN.includes(pendingView) && u.role !== "administrador") ? pendingView : null;
    pendingView = null;
    toast(`¡Hola, ${u.name.split(" ")[0]}! Sesión iniciada.`);
    go(target || (u.role === "administrador" ? "citas" : "inicio"));
  }

  const $ = s => document.querySelector(s);
  const setErr = (id, msg) => { $(id).textContent = msg || ""; };
  const regForm = $("#registerForm"), loginForm = $("#loginForm");

  /* ---------- Registro ---------- */
  function syncRole() {
    const adm = regForm.elements.role.value === "administrador";
    $("#adminCodeWrap").hidden = !adm; regForm.adminCode.required = adm;
    $("#registerTitle").textContent = adm ? "Registro de administrador" : "Crear cuenta de cliente";
  }
  regForm.querySelectorAll('[name="role"]').forEach(r => r.addEventListener("change", syncRole));

  regForm.addEventListener("submit", async e => {
    e.preventDefault(); setErr("#registerError");
    const f = regForm, name = f.elements.name.value.trim().replace(/\s+/g, " "), email = f.email.value.trim(), phone = f.phone.value.trim();
    const pw = f.password.value, pw2 = f.password2.value, role = f.elements.role.value;
    if (name.length < 3) return setErr("#registerError", "Escribe tu nombre completo.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return setErr("#registerError", "Escribe un correo válido.");
    if (!/^[0-9+ ()-]{7,20}$/.test(phone)) return setErr("#registerError", "Escribe un teléfono válido (mínimo 7 dígitos).");
    if (pw.length < 8 || !/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return setErr("#registerError", "La contraseña debe tener mínimo 8 caracteres, con letras y números.");
    if (pw !== pw2) return setErr("#registerError", "Las contraseñas no coinciden.");
    const btn = f.querySelector('button[type="submit"]'); btn.disabled = true;
    try {
      const { user } = await api("/register", { method: "POST", body: { name, email, phone, password: pw, role, adminCode: f.adminCode.value } });
      f.reset(); syncRole();
      toast(role === "administrador" ? "Cuenta de administrador creada." : "¡Cuenta creada! Ya puedes agendar tu cita.");
      afterLogin(user);
    } catch (err) { setErr("#registerError", err.message); }
    finally { btn.disabled = false; }
  });

  /* ---------- Inicio de sesión ---------- */
  loginForm.addEventListener("submit", async e => {
    e.preventDefault(); setErr("#loginError");
    const email = loginForm.email.value.trim(), password = loginForm.password.value;
    if (!email || !password) return setErr("#loginError", "Ingresa tu correo y tu contraseña.");
    const btn = loginForm.querySelector('button[type="submit"]'); btn.disabled = true;
    try {
      const { user } = await api("/login", { method: "POST", body: { email, password, remember: loginForm.remember.checked } });
      loginForm.reset(); loginForm.remember.checked = true;
      afterLogin(user);
    } catch (err) { setErr("#loginError", err.message); }
    finally { btn.disabled = false; }
  });

  /* ---------- Salir y mostrar/ocultar contraseña ---------- */
  $("#logoutBtn").addEventListener("click", async () => {
    try { await api("/logout", { method: "POST", body: {} }); } catch {}
    me = null; pendingView = null; refreshAuthUI(); toast("Sesión cerrada."); go("inicio");
  });
  document.addEventListener("click", e => {
    const t = e.target.closest("[data-toggle-pw]"); if (!t) return;
    const inp = t.parentElement.querySelector("input"), show = inp.type === "password";
    inp.type = show ? "text" : "password"; t.textContent = show ? "Ocultar" : "Mostrar";
  });

  /* ---------- Al abrir el sitio: ¿ya hay una sesión? ---------- */
  syncRole(); refreshAuthUI();
  api("/me").then(r => { me = r.user; refreshAuthUI(); }).catch(() => {});
})();
