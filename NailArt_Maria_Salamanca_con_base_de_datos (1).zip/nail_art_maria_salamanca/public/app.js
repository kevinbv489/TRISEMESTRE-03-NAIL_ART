/* Nail Art María Salamanca — interfaz. Todos los datos viven en el servidor (SQLite) vía /api. */
let data = { services: [], appointments: [], clients: [], mine: [] }; // el chatbot lee data.services
const money = n => new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 }).format(n);
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
function escapeHTML(s = "") { return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }

/* ---------- Llamadas a la API ---------- */
async function api(path, { method = "GET", body } = {}) {
  let r;
  try {
    r = await fetch("/api" + path, {
      method, credentials: "same-origin",
      headers: body !== undefined ? { "Content-Type": "application/json" } : {},
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
  } catch { throw new Error("No se pudo conectar con el servidor. Revisa que esté encendido."); }
  let j = {}; try { j = await r.json(); } catch {}
  if (!r.ok) {
    if (r.status === 401 && typeof window.onSessionExpired === "function") window.onSessionExpired();
    const err = new Error(j.error || "Ocurrió un error. Intenta de nuevo."); err.status = r.status; throw err;
  }
  return j;
}
const safe = async fn => { try { return await fn(); } catch (e) { toast(e.message); } };

/* ---------- Navegación ---------- */
function go(view) {
  $$(".view").forEach(v => v.classList.toggle("active", v.id === `view-${view}`));
  $$(".nav-link").forEach(b => b.classList.toggle("active", b.dataset.view === view));
  $("#mainNav").classList.remove("open");
  if (view === "clientes") loadClients();
  if (view === "citas") loadAppointments();
  if (view === "miscitas") loadMine();
  window.scrollTo({ top: 0, behavior: "smooth" });
}
function toast(msg) { const el = $("#toast"); el.textContent = msg; el.classList.add("show"); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove("show"), 3200); }
function formatDate(d) { if (!d) return "—"; return new Date(d.slice(0, 10) + "T12:00:00").toLocaleDateString("es-CO", { day: "2-digit", month: "short", year: "numeric" }); }

/* ---------- Servicios ---------- */
function serviceCard(s) { return `<article class="service-card"><div class="service-icon">${escapeHTML(s.icon)}</div><h3>${escapeHTML(s.name)}</h3><p>${escapeHTML(s.description)}</p><div class="service-meta"><strong>${money(s.price)}</strong><span>${s.duration} min</span></div><button class="text-button" data-book="${escapeHTML(s.id)}">Reservar este servicio →</button></article>`; }
function renderServices() {
  const keep = $("#serviceSelect").value;
  $("#featuredServices").innerHTML = data.services.slice(0, 3).map(serviceCard).join("");
  $("#allServices").innerHTML = data.services.map(serviceCard).join("");
  $("#serviceSelect").innerHTML = '<option value="">Selecciona un servicio</option>' + data.services.map(s => `<option value="${escapeHTML(s.id)}">${escapeHTML(s.name)} — ${money(s.price)}</option>`).join("");
  $("#serviceSelect").value = keep;
}
async function loadServices() { try { data.services = (await api("/services")).services; renderServices(); } catch (e) { toast(e.message); } }

/* ---------- Clientes (administrador) ---------- */
async function loadClients() { await safe(async () => { data.clients = (await api("/admin/clients")).clients; renderClients(); }); }
function renderClients() {
  const q = $("#clientSearch").value.toLowerCase();
  const list = data.clients.filter(c => (c.name + " " + c.phone + " " + c.email).toLowerCase().includes(q));
  $("#clientCount").textContent = `${list.length} cliente(s)`;
  $("#clientsBody").innerHTML = list.length
    ? list.map(c => `<tr><td><strong>${escapeHTML(c.name)}</strong></td><td>${escapeHTML(c.phone)}</td><td>${escapeHTML(c.email || "—")}</td><td>${c.count}</td><td>${formatDate(c.lastDate)}</td><td>${formatDate(c.createdAt)}</td></tr>`).join("")
    : '<tr><td colspan="6" class="empty">Aún no hay clientes registrados.</td></tr>';
}

/* ---------- Citas (administrador) ---------- */
async function loadAppointments() { await safe(async () => { data.appointments = (await api("/admin/appointments")).appointments; renderAppointments(); }); }
function renderAppointments() {
  const q = $("#appointmentSearch").value.toLowerCase(), filter = $("#statusFilter").value, all = data.appointments;
  const list = all.filter(a => (filter === "Todas" || a.status === filter) && (a.name + " " + a.service).toLowerCase().includes(q));
  $("#appointmentStats").innerHTML = [["Total", all.length], ["Pendientes", all.filter(a => a.status === "Pendiente").length], ["Confirmadas", all.filter(a => a.status === "Confirmada").length]]
    .map(([l, n]) => `<div class="stat"><span>${l}</span><strong>${n}</strong></div>`).join("");
  $("#appointmentsBody").innerHTML = list.length ? list.map(a => `<tr><td><strong>${escapeHTML(a.name)}</strong><br><span class="muted">${escapeHTML(a.phone)}</span></td><td>${escapeHTML(a.service)}</td><td>${formatDate(a.date)} · ${escapeHTML(a.time)}</td><td><span class="status ${a.status}">${a.status}</span></td><td>${a.status !== "Cancelada" ? `${a.status !== "Confirmada" ? `<button class="action-btn" data-confirm="${a.id}">Confirmar</button>` : ""}<button class="action-btn danger" data-cancel="${a.id}">Cancelar</button>` : `<button class="action-btn" data-confirm="${a.id}">Reactivar</button>`} <button class="action-btn danger" data-delete="${a.id}">Eliminar</button></td></tr>`).join("")
    : '<tr><td colspan="5" class="empty">No hay citas que coincidan con la búsqueda.</td></tr>';
}

/* ---------- Mis citas (cliente) ---------- */
async function loadMine() { await safe(async () => { data.mine = (await api("/appointments/mine")).appointments; renderMine(); }); }
function renderMine() {
  const list = data.mine;
  $("#myStats").innerHTML = [["Total", list.length], ["Pendientes", list.filter(a => a.status === "Pendiente").length], ["Confirmadas", list.filter(a => a.status === "Confirmada").length]]
    .map(([l, n]) => `<div class="stat"><span>${l}</span><strong>${n}</strong></div>`).join("");
  $("#myBody").innerHTML = list.length ? list.map(a => `<tr><td><strong>${escapeHTML(a.service)}</strong></td><td>${formatDate(a.date)} · ${escapeHTML(a.time)}</td><td><span class="status ${a.status}">${a.status}</span></td><td>${a.status !== "Cancelada" ? `<button class="action-btn danger" data-mycancel="${a.id}">Cancelar</button>` : "—"}</td></tr>`).join("")
    : '<tr><td colspan="4" class="empty">Aún no tienes citas. <button class="text-button" data-go="agendar">Agenda la primera →</button></td></tr>';
}

/* ---------- CSV ---------- */
function downloadCSV(filename, rows) {
  const csv = rows.map(row => row.map(v => '"' + String(v ?? "").replace(/"/g, '""') + '"').join(";")).join("\n");
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob), a = document.createElement("a");
  a.href = url; a.download = filename; a.click(); URL.revokeObjectURL(url);
}

/* ---------- Formulario de reserva ---------- */
function setMinDate() { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); $("#dateInput").min = d.toISOString().slice(0, 10); }
function initTimes() { $("#timeSelect").innerHTML = '<option value="">Selecciona una hora</option>' + Array.from({ length: 18 }, (_, i) => { const h = 9 + Math.floor(i / 2), m = i % 2 ? "30" : "00"; return `<option>${String(h).padStart(2, "0")}:${m}</option>`; }).join(""); }
async function refreshAvailability() {
  const date = $("#dateInput").value, sel = $("#timeSelect"), prev = sel.value;
  initTimes();
  if (!date || typeof currentUser !== "function" || !currentUser()) return;
  try {
    const { taken } = await api("/availability?date=" + encodeURIComponent(date));
    [...sel.options].forEach(o => { if (taken.includes(o.value)) { o.disabled = true; o.textContent += " (ocupada)"; } });
    if (prev && !taken.includes(prev)) sel.value = prev;
  } catch {}
}
$("#dateInput").addEventListener("change", refreshAvailability);

$("#bookingForm").addEventListener("submit", async e => {
  e.preventDefault();
  if (!currentUser()) { go("login"); return; }
  const form = e.currentTarget, f = new FormData(form), btn = form.querySelector('button[type="submit"]');
  btn.disabled = true; $("#bookingMessage").textContent = "";
  try {
    await api("/appointments", { method: "POST", body: {
      name: f.get("name"), phone: f.get("phone"), email: f.get("email"), serviceId: f.get("service"),
      date: f.get("date"), time: f.get("time"), notes: f.get("notes") } });
    form.reset(); prefillBooking(); initTimes();
    $("#bookingMessage").textContent = "¡Solicitud registrada! Tu cita quedó en estado Pendiente. Puedes verla en «Mis citas».";
    toast("Reserva registrada correctamente.");
  } catch (err) { toast(err.message); refreshAvailability(); }
  finally { btn.disabled = false; }
});

/* ---------- Clics (delegados) ---------- */
document.addEventListener("click", e => {
  const nav = e.target.closest("[data-view]"); if (nav) { e.preventDefault(); go(nav.dataset.view); return; }
  const goBtn = e.target.closest("[data-go]"); if (goBtn) { go(goBtn.dataset.go); return; }
  const book = e.target.closest("[data-book]"); if (book) { $("#serviceSelect").value = book.dataset.book; go("agendar"); return; }

  const setStatus = (id, status, msg) => safe(async () => { await api("/admin/appointments/" + id, { method: "PATCH", body: { status } }); toast(msg); await loadAppointments(); });
  const ok = e.target.closest("[data-confirm]"); if (ok) { setStatus(ok.dataset.confirm, "Confirmada", "Cita confirmada."); return; }
  const cn = e.target.closest("[data-cancel]"); if (cn) { if (window.confirm("¿Deseas cancelar esta cita?")) setStatus(cn.dataset.cancel, "Cancelada", "Cita cancelada."); return; }
  const my = e.target.closest("[data-mycancel]");
  if (my) { if (window.confirm("¿Deseas cancelar tu cita?")) safe(async () => { await api(`/appointments/${my.dataset.mycancel}/cancel`, { method: "POST", body: {} }); toast("Tu cita fue cancelada."); await loadMine(); }); return; }
  const del = e.target.closest("[data-delete]");
  if (del && window.confirm("¿Eliminar definitivamente esta cita?")) safe(async () => { await api("/admin/appointments/" + del.dataset.delete, { method: "DELETE" }); toast("Cita eliminada."); await loadAppointments(); });
});

$("#clientSearch").addEventListener("input", renderClients);
$("#appointmentSearch").addEventListener("input", renderAppointments);
$("#statusFilter").addEventListener("change", renderAppointments);
$("#exportClients").addEventListener("click", () => downloadCSV("clientes_nail_art.csv", [["Nombre", "Teléfono", "Correo", "Citas", "Última reserva", "Registro"], ...data.clients.map(c => [c.name, c.phone, c.email, c.count, formatDate(c.lastDate), formatDate(c.createdAt)])]));
$("#exportAppointments").addEventListener("click", () => downloadCSV("citas_nail_art.csv", [["Cliente", "Teléfono", "Correo", "Servicio", "Fecha", "Hora", "Estado", "Notas"], ...data.appointments.map(a => [a.name, a.phone, a.email, a.service, a.date, a.time, a.status, a.notes])]));
$("#menuToggle").addEventListener("click", () => $("#mainNav").classList.toggle("open"));
$("#year").textContent = new Date().getFullYear();
initTimes(); setMinDate(); loadServices();
