'use strict';
/* Nail Art María Salamanca — servidor (Node.js + SQLite, sin dependencias externas).
   Requiere Node.js 22.13 o superior. Inicio:  node server.js  */

const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 13)) {
  console.error(`Se requiere Node.js 22.13 o superior (https://nodejs.org). Versión actual: ${process.version}`);
  process.exit(1);
}

// Silencia solo el aviso "experimental" de node:sqlite; deja pasar los demás avisos.
process.removeAllListeners('warning');
process.on('warning', w => { if (w.name !== 'ExperimentalWarning') console.warn(w); });

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const { DatabaseSync } = require('node:sqlite');
const scrypt = promisify(crypto.scrypt);

const DEFAULT_ADMIN_CODE = 'NAILART-ADMIN-2026';

/* ------------------------------------------------------------------ */
/*  Datos iniciales                                                     */
/* ------------------------------------------------------------------ */
const SEED_SERVICES = [
  ['s1', 'Manicure tradicional', 'Limpieza, limado, cuidado de cutícula y esmaltado clásico.', 25000, 45, '✿'],
  ['s2', 'Semipermanente', 'Esmaltado de larga duración con acabado brillante.', 45000, 60, '♡'],
  ['s3', 'Uñas acrílicas', 'Extensión y construcción de uñas con acabado personalizado.', 85000, 120, '✧'],
  ['s4', 'Pedicure', 'Cuidado de pies, uñas y esmaltado tradicional.', 35000, 60, '❀'],
  ['s5', 'Diseño de uñas', 'Decoración personalizada para darle un toque único a tus uñas.', 15000, 30, '✦'],
  ['s6', 'Retiro de producto', 'Retiro cuidadoso del producto aplicado anteriormente.', 18000, 30, '❋']
];
// Horas disponibles: 09:00 a 17:30 cada 30 min (igual que el formulario).
const TIMES = Array.from({ length: 18 }, (_, i) => `${String(9 + Math.floor(i / 2)).padStart(2, '0')}:${i % 2 ? '30' : '00'}`);
const STATUSES = ['Pendiente', 'Confirmada', 'Cancelada'];

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8'
};

const httpError = (status, message) => Object.assign(new Error(message), { status });
const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');
const safeEqual = (a, b) => crypto.timingSafeEqual(crypto.createHash('sha256').update(String(a)).digest(), crypto.createHash('sha256').update(String(b)).digest());
const todayBogota = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Bogota' });

function createApp(opts = {}) {
  const dbPath = opts.dbPath || process.env.DB_PATH || path.join(__dirname, 'data', 'nailart.db');
  const adminCode = opts.adminCode || process.env.ADMIN_CODE || DEFAULT_ADMIN_CODE;
  const publicDir = opts.publicDir || path.join(__dirname, 'public');
  const secureCookies = opts.secureCookies ?? process.env.COOKIE_SECURE === '1';
  const trustProxy = opts.trustProxy ?? process.env.TRUST_PROXY === '1';

  /* ---------------- Base de datos ---------------- */
  if (dbPath !== ':memory:') fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS users (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      name          TEXT NOT NULL,
      email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
      phone         TEXT NOT NULL,
      role          TEXT NOT NULL CHECK (role IN ('cliente','administrador')),
      password_hash TEXT NOT NULL,
      created_at    TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS services (
      id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL,
      price INTEGER NOT NULL, duration INTEGER NOT NULL, icon TEXT NOT NULL, position INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS appointments (
      id           TEXT PRIMARY KEY,
      user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name         TEXT NOT NULL,
      phone        TEXT NOT NULL,
      email        TEXT NOT NULL DEFAULT '',
      service_id   TEXT NOT NULL REFERENCES services(id),
      service_name TEXT NOT NULL,
      date         TEXT NOT NULL,
      time         TEXT NOT NULL,
      notes        TEXT NOT NULL DEFAULT '',
      status       TEXT NOT NULL DEFAULT 'Pendiente' CHECK (status IN ('Pendiente','Confirmada','Cancelada')),
      created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS ix_appt_user ON appointments(user_id);
    -- Un horario solo puede tener una cita activa (la base de datos lo garantiza, aunque dos personas reserven a la vez)
    CREATE UNIQUE INDEX IF NOT EXISTS ux_appt_slot ON appointments(date, time) WHERE status <> 'Cancelada';
  `);
  if (db.prepare('SELECT COUNT(*) AS n FROM services').get().n === 0) {
    const ins = db.prepare('INSERT INTO services (id,name,description,price,duration,icon,position) VALUES (?,?,?,?,?,?,?)');
    SEED_SERVICES.forEach((s, i) => ins.run(...s, i));
  }
  const purgeSessions = () => db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now());
  purgeSessions();

  /* ---------------- Contraseñas (scrypt + sal) ---------------- */
  async function hashPassword(pw) {
    const salt = crypto.randomBytes(16);
    const key = await scrypt(pw, salt, 64);
    return `scrypt$${salt.toString('base64')}$${key.toString('base64')}`;
  }
  async function verifyPassword(pw, stored) {
    const [alg, s, k] = String(stored).split('$');
    if (alg !== 'scrypt') return false;
    const key = await scrypt(pw, Buffer.from(s, 'base64'), 64);
    const expected = Buffer.from(k, 'base64');
    return key.length === expected.length && crypto.timingSafeEqual(key, expected);
  }
  // Hash falso para que el tiempo de respuesta sea parecido cuando el correo no existe.
  const dummyHash = `scrypt$${crypto.randomBytes(16).toString('base64')}$${crypto.randomBytes(64).toString('base64')}`;

  /* ---------------- Límite de intentos ---------------- */
  const locks = new Map();   // clave -> { n, until, last }
  const hits = new Map();    // clave -> [timestamps]
  const lockedFor = key => { const a = locks.get(key); return a && a.until > Date.now() ? Math.ceil((a.until - Date.now()) / 1000) : 0; };
  function registerFailure(key, max = 5, lockMs = 60_000) {
    let a = locks.get(key) || { n: 0, until: 0, last: 0 };
    if (a.until && a.until <= Date.now()) a = { n: 0, until: 0, last: 0 };
    a.n++; a.last = Date.now();
    if (a.n >= max) { a.until = Date.now() + lockMs; a.n = 0; }
    locks.set(key, a);
  }
  function rateLimit(key, limit, windowMs) {
    const now = Date.now(), arr = (hits.get(key) || []).filter(t => now - t < windowMs);
    if (arr.length >= limit) { hits.set(key, arr); return false; }
    arr.push(now); hits.set(key, arr); return true;
  }
  const janitor = setInterval(() => {
    const now = Date.now();
    for (const [k, a] of locks) if (a.until < now && now - a.last > 3_600_000) locks.delete(k);
    for (const [k, arr] of hits) if (!arr.some(t => now - t < 3_600_000)) hits.delete(k);
    purgeSessions();
  }, 600_000);
  janitor.unref();

  /* ---------------- Sesiones ---------------- */
  function parseCookies(req) {
    const out = {};
    String(req.headers.cookie || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) out[p.slice(0, i).trim()] = p.slice(i + 1).trim(); });
    return out;
  }
  const isSecure = req => secureCookies || (trustProxy && req.headers['x-forwarded-proto'] === 'https');
  function setSessionCookie(req, res, token, maxAgeSec) {
    const parts = [`sid=${token}`, 'HttpOnly', 'SameSite=Lax', 'Path=/'];
    if (maxAgeSec != null) parts.push(`Max-Age=${maxAgeSec}`);
    if (isSecure(req)) parts.push('Secure');
    res.setHeader('Set-Cookie', parts.join('; '));
  }
  function createSession(req, res, userId, remember) {
    const token = crypto.randomBytes(32).toString('base64url');
    const ttl = remember ? 30 * 86_400_000 : 24 * 3_600_000;
    db.prepare('INSERT INTO sessions (token_hash,user_id,expires_at) VALUES (?,?,?)').run(sha256(token), userId, Date.now() + ttl);
    setSessionCookie(req, res, token, remember ? Math.floor(ttl / 1000) : null);
  }
  function currentUser(req) {
    const token = parseCookies(req).sid;
    if (!token) return null;
    return db.prepare(`SELECT u.id,u.name,u.email,u.phone,u.role FROM sessions s JOIN users u ON u.id=s.user_id
                       WHERE s.token_hash=? AND s.expires_at>?`).get(sha256(token), Date.now()) || null;
  }
  const requireUser = req => { const u = currentUser(req); if (!u) throw httpError(401, 'Debes iniciar sesión.'); return u; };
  const requireAdmin = req => { const u = requireUser(req); if (u.role !== 'administrador') throw httpError(403, 'Acceso solo para administradores.'); return u; };

  /* ---------------- Utilidades HTTP ---------------- */
  const clientIp = req => (trustProxy && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || 'ip';
  function send(res, status, body, headers = {}) {
    res.writeHead(status, headers); res.end(body);
  }
  const json = (res, status, obj) => send(res, status, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  function readBody(req, limit = 32 * 1024) {
    return new Promise((resolve, reject) => {
      let size = 0, tooBig = false; const chunks = [];
      req.on('data', c => { size += c.length; if (size > limit) { tooBig = true; return; } chunks.push(c); });
      req.on('end', () => {
        if (tooBig) return reject(httpError(413, 'Solicitud demasiado grande.'));
        if (!chunks.length) return resolve({});
        try {
          const j = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          if (j === null || typeof j !== 'object' || Array.isArray(j)) throw new Error();
          resolve(j);
        } catch { reject(httpError(400, 'Los datos enviados no son válidos.')); }
      });
      req.on('error', reject);
    });
  }
  const text = (v, max) => (typeof v === 'string' ? v.trim().replace(/\s+/g, ' ').slice(0, max) : '');
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const PHONE_RE = /^[0-9+ ()-]{7,20}$/;
  const publicUser = u => ({ id: u.id, name: u.name, email: u.email, phone: u.phone, role: u.role });
  const mapAppt = r => ({ id: r.id, userId: r.user_id, name: r.name, phone: r.phone, email: r.email, service: r.service_name, serviceId: r.service_id, date: r.date, time: r.time, notes: r.notes, status: r.status, createdAt: r.created_at });
  const isUnique = e => /UNIQUE constraint failed/i.test(String(e && e.message));

  function validDate(d) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return false;
    const t = new Date(d + 'T00:00:00Z');
    return !isNaN(t) && t.toISOString().slice(0, 10) === d;
  }

  /* ---------------- API ---------------- */
  async function api(req, res, url) {
    const method = req.method, p = url.pathname;

    // Protección CSRF: las peticiones que modifican datos deben venir de este mismo sitio y en JSON.
    if (method !== 'GET' && method !== 'HEAD') {
      const origin = req.headers.origin;
      if (origin) { let ok = false; try { ok = new URL(origin).host === req.headers.host; } catch {} if (!ok) throw httpError(403, 'Origen no permitido.'); }
      if (method !== 'DELETE' && !String(req.headers['content-type'] || '').startsWith('application/json')) throw httpError(415, 'Se esperaba JSON.');
    }

    /* --- Público --- */
    if (method === 'GET' && p === '/api/services') {
      return json(res, 200, { services: db.prepare('SELECT id,name,description,price,duration,icon FROM services ORDER BY position').all() });
    }
    if (method === 'GET' && p === '/api/me') {
      const u = currentUser(req); return json(res, 200, { user: u ? publicUser(u) : null });
    }

    /* --- Registro --- */
    if (method === 'POST' && p === '/api/register') {
      const ip = clientIp(req);
      if (!rateLimit('reg|' + ip, 20, 600_000)) throw httpError(429, 'Demasiados registros desde esta conexión. Intenta más tarde.');
      const b = await readBody(req);
      const name = text(b.name, 80), email = text(b.email, 120).toLowerCase(), phone = text(b.phone, 20);
      const pw = typeof b.password === 'string' ? b.password : '', role = b.role === 'administrador' ? 'administrador' : 'cliente';
      if (name.length < 3) throw httpError(400, 'Escribe tu nombre completo.');
      if (!EMAIL_RE.test(email)) throw httpError(400, 'Escribe un correo válido.');
      if (!PHONE_RE.test(phone)) throw httpError(400, 'Escribe un teléfono válido (mínimo 7 dígitos).');
      if (pw.length < 8 || pw.length > 128 || !/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) throw httpError(400, 'La contraseña debe tener mínimo 8 caracteres, con letras y números.');
      if (role === 'administrador') {
        const k = 'adm|' + ip;
        const wait = lockedFor(k);
        if (wait) throw httpError(429, `Demasiados intentos con el código. Espera ${wait} s.`);
        if (typeof b.adminCode !== 'string' || !safeEqual(b.adminCode.trim(), adminCode)) {
          registerFailure(k); throw httpError(403, 'El código de administrador no es correcto.');
        }
      }
      let id;
      try {
        const r = db.prepare('INSERT INTO users (name,email,phone,role,password_hash) VALUES (?,?,?,?,?)').run(name, email, phone, role, await hashPassword(pw));
        id = Number(r.lastInsertRowid);
      } catch (e) {
        if (isUnique(e)) throw httpError(409, 'Ya existe una cuenta con ese correo. Inicia sesión.');
        throw e;
      }
      createSession(req, res, id, true);
      return json(res, 201, { user: publicUser({ id, name, email, phone, role }) });
    }

    /* --- Login / logout --- */
    if (method === 'POST' && p === '/api/login') {
      const b = await readBody(req);
      const email = text(b.email, 120).toLowerCase(), pw = typeof b.password === 'string' ? b.password.slice(0, 128) : '';
      if (!email || !pw) throw httpError(400, 'Ingresa tu correo y tu contraseña.');
      const key = clientIp(req) + '|' + email;
      const wait = lockedFor(key);
      if (wait) throw httpError(429, `Demasiados intentos. Intenta de nuevo en ${wait} s.`);
      const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
      const ok = await verifyPassword(pw, row ? row.password_hash : dummyHash);
      if (!row || !ok) {
        registerFailure(key);
        throw httpError(401, lockedFor(key) ? 'Demasiados intentos fallidos. Espera 1 minuto.' : 'Correo o contraseña incorrectos.');
      }
      locks.delete(key);
      createSession(req, res, row.id, b.remember !== false);
      return json(res, 200, { user: publicUser(row) });
    }
    if (method === 'POST' && p === '/api/logout') {
      const token = parseCookies(req).sid;
      if (token) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(sha256(token));
      setSessionCookie(req, res, '', 0);
      return json(res, 200, { ok: true });
    }

    /* --- Cliente (sesión iniciada) --- */
    if (method === 'GET' && p === '/api/availability') {
      requireUser(req);
      const date = url.searchParams.get('date') || '';
      if (!validDate(date)) throw httpError(400, 'Fecha no válida.');
      const taken = db.prepare("SELECT time FROM appointments WHERE date=? AND status<>'Cancelada'").all(date).map(r => r.time);
      return json(res, 200, { taken });
    }
    if (method === 'POST' && p === '/api/appointments') {
      const user = requireUser(req);
      if (!rateLimit('appt|' + user.id, 30, 3_600_000)) throw httpError(429, 'Demasiadas solicitudes. Intenta más tarde.');
      const b = await readBody(req);
      const name = text(b.name, 80), phone = text(b.phone, 20), email = text(b.email, 120).toLowerCase(), notes = text(b.notes, 500);
      const date = text(b.date, 10), time = text(b.time, 5);
      const svc = db.prepare('SELECT id,name FROM services WHERE id=?').get(text(b.serviceId, 20));
      if (name.length < 3) throw httpError(400, 'Escribe el nombre completo.');
      if (!PHONE_RE.test(phone)) throw httpError(400, 'Escribe un teléfono válido.');
      if (email && !EMAIL_RE.test(email)) throw httpError(400, 'El correo no es válido.');
      if (!svc) throw httpError(400, 'Selecciona un servicio.');
      if (!validDate(date)) throw httpError(400, 'Selecciona una fecha válida.');
      if (date < todayBogota()) throw httpError(400, 'La fecha no puede estar en el pasado.');
      if (!TIMES.includes(time)) throw httpError(400, 'Selecciona una hora válida.');
      const id = crypto.randomUUID();
      try {
        db.prepare('INSERT INTO appointments (id,user_id,name,phone,email,service_id,service_name,date,time,notes) VALUES (?,?,?,?,?,?,?,?,?,?)')
          .run(id, user.id, name, phone, email, svc.id, svc.name, date, time, notes);
      } catch (e) {
        if (isUnique(e)) throw httpError(409, 'Ese horario ya tiene una solicitud. Elige otra hora.');
        throw e;
      }
      return json(res, 201, { appointment: mapAppt(db.prepare('SELECT * FROM appointments WHERE id=?').get(id)) });
    }
    if (method === 'GET' && p === '/api/appointments/mine') {
      const user = requireUser(req);
      const rows = db.prepare('SELECT * FROM appointments WHERE user_id=? ORDER BY date, time').all(user.id);
      return json(res, 200, { appointments: rows.map(mapAppt) });
    }
    let m = p.match(/^\/api\/appointments\/([\w-]{1,64})\/cancel$/);
    if (method === 'POST' && m) {
      const user = requireUser(req);
      const r = db.prepare("UPDATE appointments SET status='Cancelada' WHERE id=? AND user_id=?").run(m[1], user.id);
      if (!r.changes) throw httpError(404, 'Cita no encontrada.');
      return json(res, 200, { ok: true });
    }

    /* --- Administrador --- */
    if (method === 'GET' && p === '/api/admin/appointments') {
      requireAdmin(req);
      return json(res, 200, { appointments: db.prepare('SELECT * FROM appointments ORDER BY date, time').all().map(mapAppt) });
    }
    if (method === 'GET' && p === '/api/admin/clients') {
      requireAdmin(req);
      const rows = db.prepare(`SELECT u.id,u.name,u.email,u.phone,u.created_at AS createdAt,
          COUNT(a.id) AS count, MAX(a.date) AS lastDate
        FROM users u LEFT JOIN appointments a ON a.user_id=u.id
        WHERE u.role='cliente' GROUP BY u.id ORDER BY u.name COLLATE NOCASE`).all();
      return json(res, 200, { clients: rows });
    }
    m = p.match(/^\/api\/admin\/appointments\/([\w-]{1,64})$/);
    if (m && method === 'PATCH') {
      requireAdmin(req);
      const b = await readBody(req);
      if (!STATUSES.includes(b.status)) throw httpError(400, 'Estado no válido.');
      try {
        const r = db.prepare('UPDATE appointments SET status=? WHERE id=?').run(b.status, m[1]);
        if (!r.changes) throw httpError(404, 'Cita no encontrada.');
      } catch (e) {
        if (isUnique(e)) throw httpError(409, 'No se puede reactivar: ese horario ya fue tomado por otra cita.');
        throw e;
      }
      return json(res, 200, { ok: true });
    }
    if (m && method === 'DELETE') {
      requireAdmin(req);
      const r = db.prepare('DELETE FROM appointments WHERE id=?').run(m[1]);
      if (!r.changes) throw httpError(404, 'Cita no encontrada.');
      return json(res, 200, { ok: true });
    }

    throw httpError(404, 'Ruta no encontrada.');
  }

  /* ---------------- Archivos estáticos ---------------- */
  function serveStatic(req, res, pathname) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Método no permitido', { Allow: 'GET, HEAD' });
    let rel;
    try { rel = decodeURIComponent(pathname); } catch { return send(res, 400, 'Solicitud incorrecta'); }
    if (rel.includes('\0')) return send(res, 400, 'Solicitud incorrecta');
    if (rel.endsWith('/')) rel += 'index.html';
    const file = path.resolve(publicDir, '.' + path.sep + rel);
    const rootPrefix = path.resolve(publicDir) + path.sep;
    const hidden = path.relative(publicDir, file).split(path.sep).some(s => s.startsWith('.'));
    if (!file.startsWith(rootPrefix) || hidden) return send(res, 404, 'No encontrado', { 'Content-Type': 'text/plain; charset=utf-8' });
    fs.stat(file, (err, st) => {
      if (err || !st.isFile()) return send(res, 404, 'No encontrado', { 'Content-Type': 'text/plain; charset=utf-8' });
      const headers = { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'no-cache' };
      res.writeHead(200, headers);
      if (req.method === 'HEAD') return res.end();
      fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
    });
  }

  /* ---------------- Servidor ---------------- */
  const CSP = "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'";
  const server = http.createServer(async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'same-origin');
    res.setHeader('Content-Security-Policy', CSP);
    try {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname.startsWith('/api/')) return await api(req, res, url);
      return serveStatic(req, res, url.pathname);
    } catch (e) {
      if (e.status) return json(res, e.status, { error: e.message });
      console.error(e);
      if (!res.headersSent) return json(res, 500, { error: 'Error interno del servidor.' });
      res.end();
    }
  });
  server.on('close', () => { clearInterval(janitor); try { db.close(); } catch {} });
  server.usingDefaultAdminCode = adminCode === DEFAULT_ADMIN_CODE;
  return server;
}

module.exports = { createApp };

if (require.main === module) {
  const PORT = Number(process.env.PORT) || 3000;
  const HOST = process.env.HOST || (process.env.PORT ? '0.0.0.0' : '127.0.0.1');
  const server = createApp();
  server.listen(PORT, HOST, () => {
    console.log(`\n  Nail Art María Salamanca en marcha → http://localhost:${PORT}\n`);
    if (server.usingDefaultAdminCode) console.warn('  ⚠  Usas el código de administrador por defecto. Cámbialo con la variable ADMIN_CODE antes de publicar.\n');
  });
  const stop = () => server.close(() => process.exit(0));
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
}
