#!/bin/sh
# === CAMBIA ESTE CÓDIGO antes de usar el sitio ===
export ADMIN_CODE="NAILART-ADMIN-2026"
cd "$(dirname "$0")"
echo "Iniciando Nail Art... abre http://localhost:3000"
node server.js
