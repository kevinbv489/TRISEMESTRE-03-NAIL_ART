@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem === CAMBIA ESTE CODIGO antes de usar el sitio ===
set ADMIN_CODE=NAILART-ADMIN-2026

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  No se encontro Node.js en este computador.
  echo  Instalalo desde https://nodejs.org ^(version LTS^), reinicia el PC y abre este archivo otra vez.
  echo.
  pause
  exit /b
)

echo.
echo  Iniciando Nail Art... NO CIERRES esta ventana mientras uses el sitio.
echo  Se abrira el navegador en http://localhost:3000
echo.
start "" cmd /c "timeout /t 3 >nul & start http://localhost:3000"
node server.js
echo.
echo  El servidor se detuvo. Si arriba aparece un error, copialo y envialo.
pause
