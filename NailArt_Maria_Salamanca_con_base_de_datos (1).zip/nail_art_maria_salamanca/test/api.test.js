'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../server.js');

let server, base;
const CODE = 'CODIGO-DE-PRUEBA';
test.before(async () => {
  server = createApp({ dbPath: ':memory:', adminCode: CODE });
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => new Promise(r => server.close(r)));

// Cliente HTTP mínimo con "jar" de cookies
function agent() {
  let cookie = '';
  return async (method, path, body, headers = {}) => {
    const r = await fetch(base + path, {
      method, redirect: 'manual',
      headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...headers },
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
    const sc = r.headers.get('set-cookie');
    if (sc) { const c = sc.split(';')[0]; cookie = c.endsWith('=') ? '' : c; }
    let j = null; try { j = await r.clone().json(); } catch {}
    return { status: r.status, body: j, headers: r.headers, res: r };
  };
}
const futureDate = (d = 30) => new Date(Date.now() + d * 864e5).toISOString().slice(0, 10);
const laura = { name: 'Laura Gómez', email: 'laura@mail.com', phone: '3001234567', password: 'Clave1234', role: 'cliente' };
const maria = { name: 'María Salamanca', email: 'maria@mail.com', phone: '3109998877', password: 'Admin2026x', role: 'administrador', adminCode: CODE };

test('servicios públicos y sesión vacía', async () => {
  const a = agent();
  const s = await a('GET', '/api/services');
  assert.equal(s.status, 200); assert.equal(s.body.services.length, 6);
  assert.equal((await a('GET', '/api/me')).body.user, null);
});

test('registro valida datos y no guarda la contraseña en claro', async () => {
  const a = agent();
  assert.equal((await a('POST', '/api/register', { ...laura, password: 'abc' })).status, 400);
  assert.equal((await a('POST', '/api/register', { ...laura, email: 'malo' })).status, 400);
  const ok = await a('POST', '/api/register', laura);
  assert.equal(ok.status, 201); assert.equal(ok.body.user.role, 'cliente');
  assert.equal(ok.body.user.password_hash, undefined);
  assert.ok(/HttpOnly/i.test(ok.headers.get('set-cookie')));
  assert.equal((await a('GET', '/api/me')).body.user.email, 'laura@mail.com');
  assert.equal((await agent()('POST', '/api/register', { ...laura, email: 'LAURA@mail.com' })).status, 409, 'correo duplicado (sin importar mayúsculas)');
});

test('administrador exige el código correcto (validado en el servidor)', async () => {
  assert.equal((await agent()('POST', '/api/register', { ...maria, adminCode: 'MAL' })).status, 403);
  assert.equal((await agent()('POST', '/api/register', { ...maria, adminCode: undefined })).status, 403);
  const ok = await agent()('POST', '/api/register', maria);
  assert.equal(ok.status, 201); assert.equal(ok.body.user.role, 'administrador');
});

test('un cliente no puede hacerse administrador mandando role=administrador sin código', async () => {
  const r = await agent()('POST', '/api/register', { name: 'Intruso Uno', email: 'x@mail.com', phone: '3000000000', password: 'Clave1234', role: 'administrador' });
  assert.equal(r.status, 403);
});

test('login correcto, incorrecto y bloqueo por intentos', async () => {
  const a = agent();
  const bad = await a('POST', '/api/login', { email: 'laura@mail.com', password: 'nope' });
  assert.equal(bad.status, 401); assert.match(bad.body.error, /incorrectos/);
  assert.equal((await a('POST', '/api/login', { email: 'noexiste@mail.com', password: 'Clave1234' })).status, 401);
  const good = await a('POST', '/api/login', { email: 'LAURA@mail.com', password: 'Clave1234' });
  assert.equal(good.status, 200);
  const b = agent();
  for (let i = 0; i < 5; i++) await b('POST', '/api/login', { email: 'laura@mail.com', password: 'mala' + i });
  const locked = await b('POST', '/api/login', { email: 'laura@mail.com', password: 'Clave1234' });
  assert.equal(locked.status, 429, 'bloqueado aunque la clave sea correcta');
});

test('permisos: sin sesión, cliente y administrador', async () => {
  const guest = agent(), cli = agent(), adm = agent();
  await cli('POST', '/api/login', { email: 'laura@mail.com', password: 'Clave1234', remember: true }).catch(() => {});
  // el login de laura pudo quedar bloqueado por la prueba anterior (otra IP:email igual) → usar cuenta nueva
  await cli('POST', '/api/register', { name: 'Pedro Pérez', email: 'pedro@mail.com', phone: '3112223344', password: 'Clave1234', role: 'cliente' });
  await adm('POST', '/api/login', { email: 'maria@mail.com', password: 'Admin2026x' });
  for (const [m, p] of [['GET', '/api/admin/appointments'], ['GET', '/api/admin/clients'], ['GET', '/api/appointments/mine'], ['GET', '/api/availability?date=2030-01-01']])
    assert.equal((await guest(m, p)).status, 401, `${p} sin sesión`);
  for (const [m, p, b] of [['GET', '/api/admin/appointments'], ['GET', '/api/admin/clients'], ['PATCH', '/api/admin/appointments/x', { status: 'Confirmada' }], ['DELETE', '/api/admin/appointments/x']])
    assert.equal((await cli(m, p, b)).status, 403, `${p} como cliente`);
  assert.equal((await adm('GET', '/api/admin/appointments')).status, 200);
  assert.equal((await adm('GET', '/api/admin/clients')).status, 200);
});

test('citas: crear, validar, horario único, cancelar solo las propias', async () => {
  const c1 = agent(), c2 = agent(), adm = agent();
  await c1('POST', '/api/register', { name: 'Ana Ruiz', email: 'ana@mail.com', phone: '3151112233', password: 'Clave1234', role: 'cliente' });
  await c2('POST', '/api/register', { name: 'Eva Mora', email: 'eva@mail.com', phone: '3164445566', password: 'Clave1234', role: 'cliente' });
  await adm('POST', '/api/login', { email: 'maria@mail.com', password: 'Admin2026x' });
  const date = futureDate(), appt = { name: 'Ana Ruiz', phone: '3151112233', email: 'ana@mail.com', serviceId: 's2', date, time: '10:00', notes: 'Rosa' };

  assert.equal((await c1('POST', '/api/appointments', { ...appt, date: '2020-01-01' })).status, 400, 'fecha pasada');
  assert.equal((await c1('POST', '/api/appointments', { ...appt, time: '03:00' })).status, 400, 'hora fuera de horario');
  assert.equal((await c1('POST', '/api/appointments', { ...appt, serviceId: 'zzz' })).status, 400, 'servicio inexistente');
  assert.equal((await c1('POST', '/api/appointments', { ...appt, date: '2030-02-31' })).status, 400, 'fecha imposible');

  const made = await c1('POST', '/api/appointments', appt);
  assert.equal(made.status, 201); assert.equal(made.body.appointment.status, 'Pendiente'); assert.equal(made.body.appointment.service, 'Semipermanente');
  const id = made.body.appointment.id;

  assert.equal((await c2('POST', '/api/appointments', { ...appt, name: 'Eva Mora' })).status, 409, 'mismo horario ocupado');
  assert.deepEqual((await c2('GET', `/api/availability?date=${date}`)).body.taken, ['10:00']);
  assert.equal((await c2('GET', '/api/appointments/mine')).body.appointments.length, 0, 'Eva no ve citas de Ana');
  assert.equal((await c2('POST', `/api/appointments/${id}/cancel`, {})).status, 404, 'Eva no puede cancelar la de Ana');

  assert.equal((await adm('PATCH', `/api/admin/appointments/${id}`, { status: 'Confirmada' })).status, 200);
  assert.equal((await c1('GET', '/api/appointments/mine')).body.appointments[0].status, 'Confirmada');
  assert.equal((await adm('PATCH', `/api/admin/appointments/${id}`, { status: 'Rara' })).status, 400);

  assert.equal((await c1('POST', `/api/appointments/${id}/cancel`, {})).status, 200);
  assert.equal((await c2('POST', '/api/appointments', { ...appt, name: 'Eva Mora' })).status, 201, 'el horario liberado se puede reservar');
  const clients = (await adm('GET', '/api/admin/clients')).body.clients;
  assert.ok(clients.find(c => c.email === 'ana@mail.com').count === 1);
  assert.equal((await adm('DELETE', `/api/admin/appointments/${id}`)).status, 200);
});

test('CSRF, JSON obligatorio, límite de tamaño y logout', async () => {
  const a = agent();
  const evil = await a('POST', '/api/login', { email: 'a@b.co', password: 'x' }, { Origin: 'https://sitio-malo.com' });
  assert.equal(evil.status, 403);
  const form = await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: 'x' });
  assert.equal(form.status, 415);
  const big = await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'a'.repeat(100000) }) });
  assert.equal(big.status, 413);
  await a('POST', '/api/login', { email: 'maria@mail.com', password: 'Admin2026x' });
  assert.equal((await a('GET', '/api/admin/clients')).status, 200);
  await a('POST', '/api/logout', {});
  assert.equal((await a('GET', '/api/admin/clients')).status, 401, 'tras salir ya no hay acceso');
});

test('archivos estáticos: sirve el sitio, bloquea rutas fuera de public y expone cabeceras de seguridad', async () => {
  const idx = await fetch(base + '/');
  assert.equal(idx.status, 200); assert.match(idx.headers.get('content-type'), /text\/html/);
  assert.ok(idx.headers.get('content-security-policy')); assert.equal(idx.headers.get('x-content-type-options'), 'nosniff');
  for (const p of ['/../server.js', '/%2e%2e/server.js', '/..%2fserver.js', '/data/nailart.db', '/.env', '/nope.html'])
    assert.ok([400, 404].includes((await fetch(base + p)).status), p);
  assert.equal((await fetch(base + '/server.js')).status, 404, 'el código del servidor no es público');
  assert.equal((await fetch(base + '/app.js')).status, 200);
});
